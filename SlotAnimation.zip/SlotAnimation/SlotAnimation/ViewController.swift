//
//  ViewController.swift
//  SlotAnimation
//
//  Created by Hasitha Mapalagama on 7/29/19.
//  Copyright © 2019 Hasitha Mapalagama. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var slot3: Slot!
    @IBOutlet weak var slot2: Slot!
    @IBOutlet weak var slot1: Slot!
    
    var isRunning = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        let imgArray = [
            Item(value: "1", it: "1"),
            Item(value: "2", it: "2"),
            Item(value: "3", it: "3"),
            Item(value: "4", it: "4"),
            Item(value: "5", it: "5"),
            Item(value: "6", it: "6"),
            Item(value: "7", it: "7")
        ]
        
        slot1.viewType = .image
        slot2.viewType = .image
        slot2.isReverse = true
        slot3.viewType = .image
        
        slot1.initializeViews(dataSource: imgArray)
        slot2.initializeViews(dataSource: imgArray)
        slot3.initializeViews(dataSource: imgArray)
    }
    
    @IBAction func didClickSpin(_ sender: Any) {
        slot1.animate(finalValue: Item(value: "8", it: "8"), times: 10, speed: 0.8, completion: {
            print("slot 1 ", self.slot1.finalValue?.value as Any)
        })
        slot2.animate(finalValue: Item(value: "8", it: "8"), times: 12, speed: 0.6, completion: {
            print("slot 2 ", self.slot2.finalValue?.value)
        })
        slot3.animate(finalValue:  Item(value: "8", it: "8"), times: 18, speed: 0.4, completion: {
            print("slot 3 ", self.slot3.finalValue?.value)
        })
    }
    
    @IBAction func didClickInf(_ sender: Any) {
        if !isRunning {
            slot1.animate(finalValue: Item(value: "8", it: "8"), times: Int.max, speed: 0.7, completion: {
                print("slot 1 ", self.slot1.finalValue?.value)
            })
            slot2.animate(finalValue: Item(value: "8", it: "8"), times: Int.max, speed: 0.6, completion: {
                 print("slot 2 ", self.slot2.finalValue?.value)
            })
            slot3.animate(finalValue:  Item(value: "8", it: "8"), times: Int.max, speed: 0.5, completion: {
                 print("slot 3 ", self.slot3.finalValue?.value)
            })
        }else{
            slot1.stop()
            slot2.stop()
            slot3.stop()
            
        }
        isRunning = !isRunning
    }
    
    
}

