//
//  TestVC.swift
//  RestAPITest
//
//  Created by Hasitha Mapalagama on 7/22/19.
//  Copyright © 2019 Hasitha Mapalagama. All rights reserved.
//

import Foundation
import UIKit
class TestVC : UIViewController {
    
    var x = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setupTable()
        self.fetchData()
        
        LotteryService.shared.fetchLotteries(handler: {
           
        })
    }
    
    
    
    private func setupTable() {
        
        
        var price = 29.073793772
        var roundedPrice = 8931749812794.2184198241.toStr()
        
    }
    
    private func fetchData() {
        DispatchQueue.main.async {
            
        }
    }
    
    
  
}


class LotteryService {
    
    static var shared = LotteryService()
    
    var listOfData = [String]()
    
    
    func fetchLotteries(handler : @escaping (() -> Void)) {
        let endpoint = Endpoint.init(url: "http://dummy.restapiexample.com/api/v1/employees")
        let net = Net.init(url: endpoint, method: TMethod.post, param: [
            "username" : "Hasitha" as AnyObject,
            "password" : "123" as AnyObject
            ])
        net.expected = .data
        net.onError = { error in
            
        }
        net.onCompletion = { data in
            
           // listofData = decode(data)
            handler()
        }
        net.perform()
        
        
    }

    
}

