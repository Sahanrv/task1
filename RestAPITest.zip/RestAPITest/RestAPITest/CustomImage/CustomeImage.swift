//
//  CustomeImage.swift
//  RestAPITest
//
//  Created by Hasitha Mapalagama on 7/29/19.
//  Copyright © 2019 Hasitha Mapalagama. All rights reserved.
//

import Foundation
import UIKit
class CustomImage : UIView {
    
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var secondView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.initXib()
    }
    
    func initXib() {
        let xib = UINib.init(nibName: "CustomImage", bundle: nil)
        let view = xib.instantiate(withOwner: self, options: nil).first as! UIView
        view.frame = self.bounds
        view.autoresizingMask = [
            .flexibleHeight, .flexibleWidth
        ]
        addSubview(view)
    }
    
}
