//
//  ViewController.swift
//  RestAPITest
//
//  Created by Hasitha Mapalagama on 7/18/19.
//  Copyright © 2019 Hasitha Mapalagama. All rights reserved.
//

import UIKit
import SwiftyJSON
class ViewController: UIViewController  {
    @IBOutlet weak var view1: CustomImage!
    @IBOutlet weak var view2: CustomImage!


    
    override func viewDidLoad() {
        super.viewDidLoad()
       view1.mainView.backgroundColor = .blue
        view2.mainView.backgroundColor = .brown
        
        view1.secondView.backgroundColor = .black
        view2.secondView.backgroundColor = .gray
    }

    
}
