//
//  Double+Round.swift
//  RestAPITest
//
//  Created by Hasitha Mapalagama on 7/22/19.
//  Copyright © 2019 Hasitha Mapalagama. All rights reserved.
//

import Foundation
import UIKit

extension Double {
    func toStr() -> String {
        return String(format: "%.2f", self)
    }
}
