//
//  ViewController.swift
//  Test
//
//  Created by Treinetic Mackbook 005 on 8/15/19.
//  Copyright © 2019 Treinetic Mackbook 005. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ballTopCons: NSLayoutConstraint!
    @IBOutlet weak var ball: UIImageView!
    
    var guesture : UIPanGestureRecognizer!
    
    override func viewDidLoad() {
        super.viewDidLoad()
       self.addAView()
        
        guesture = UIPanGestureRecognizer(target: self, action: #selector(didSwipe))
        self.view.addGestureRecognizer(guesture)
    }

    
    
    @objc func didSwipe(sender : UIPanGestureRecognizer) {
        if sender.state == .ended {
            
            let x = sender.velocity(in: self.view).x
            let y = sender.velocity(in: self.view).y
            let velocity = min(max(abs(x), abs(y)), 1000)
            print("rotate now", velocity)
            let animation = CABasicAnimation.init(keyPath: "transform.rotation")
            animation.fromValue = velocity * -1
            animation.duration = 10
            animation.timingFunction = .init(controlPoints: 0.1, 0.3, 0.5, 1)
            self.ball.layer.add(animation, forKey: "transform.rotation")
            self.ball.transform = CGAffineTransform.init(rotationAngle: velocity * -1)
            
            
        }
    }
    
    func addAView() {
        DispatchQueue.main.async {
            let h = self.ball.frame.height
            let y = h * -0.4
            self.ballTopCons.constant = y
            self.view.layoutIfNeeded()
        }
    }
    

}

