//
//  selectItem.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/22/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
import UIKit
import SwiftEntryKit

class SelectItem: UIView{
    @IBOutlet weak var playerImage: UIImageView!
    @IBOutlet weak var playerPoints: UILabel!
    @IBOutlet weak var playerItem: UIImageView!
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.initXib()
    }
    
    private func initXib() {
        let nib = UINib.init(nibName: "selectItem", bundle: nil)
        let view = nib.instantiate(withOwner: self, options: nil).first as! UIView
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    
}
