//
//  selectItemView.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/27/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
import UIKit
import SwiftEntryKit

class SelectItems: UIView {
   
    @IBOutlet weak var selctetItemLbl: UILabel!
    override init(frame: CGRect) {
        super.init(frame: frame)
        initXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initXib()
       // uiConfig()
    }
    
    private func initXib() {
        let nib = UINib.init(nibName: "selectItemView", bundle: nil)
        let view =  nib.instantiate(withOwner: self, options: nil).first as! UIView
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    func uiConfig(){
        //self.playerLabel.textColor = UIColor(named: labelColor(item: self.playerItem.restorationIdentifier!))
    }
}
