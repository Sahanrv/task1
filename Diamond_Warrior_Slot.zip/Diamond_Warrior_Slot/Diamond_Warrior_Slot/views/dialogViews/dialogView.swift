//
//  dialogView.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/22/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
import UIKit
import SwiftEntryKit

class Dialog: UIView{
    
    @IBOutlet weak var playerImage: UIImageView!
    @IBOutlet weak var playerItem: UIImageView!
    @IBOutlet weak var playerLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initXib()
        uiConfig()
    }
    
    private func initXib() {
        let nib = UINib.init(nibName: "dialogView", bundle: nil)
        let view = nib.instantiate(withOwner: self, options: nil).first as! UIView
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        addSubview(view)
    }
    
    func uiConfig(){
        self.playerLabel.textColor = UIColor(named: labelColor(item: self.playerItem.restorationIdentifier!))
    }
    
    func labelColor(item: String)-> String {
        var color = ""
        if item == "d1" {
            color = "d1c"
        }else if item == "d2" {
            color = "d2c"
        }else if item == "d3" {
            color = "d3c"
        }else if item == "d4" {
            color = "d4c"
        }
        return color
    }
    
}
