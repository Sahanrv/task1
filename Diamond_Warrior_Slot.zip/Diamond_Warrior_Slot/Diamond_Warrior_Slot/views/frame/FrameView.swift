//
//  frameView.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/12/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
import UIKit

class FrameView: UIView{
    
    @IBOutlet weak var frameView: UIView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.initXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.initXib()
        self.uiConfig()
    }
    
    private func initXib() {
        let nib = UINib.init(nibName: "FrameView", bundle: nil)
        let view = nib.instantiate(withOwner: self, options: nil).first as! UIView
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
       // view.layer.cornerRadius = 10
        addSubview(view)
    }
    
    func uiConfig(){
        self.frameView.layer.borderColor = UIColor(named: "frame")?.cgColor
        self.frameView.layer.borderWidth = 3
        self.frameView.layer.cornerRadius = 10
    }
}
