//
//  diamond.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/20/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
import UIKit

class DiamondView: UIView{
    
    @IBOutlet weak var itemImage: UIImageView!
    var selectItem : (() -> Void)?
    @IBOutlet weak var itemPoints: UILabel!
    
    override init(frame: CGRect){
        super.init(frame: frame)
        self.initXib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.initXib()
        //self.uiConfig()
    }
    
    private func initXib() {
        let nib = UINib.init(nibName: "diamond", bundle: nil)
        let view = nib.instantiate(withOwner: self, options: nil).first as! UIView
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        // view.layer.cornerRadius = 10
        addSubview(view)
    }
    
    @IBAction func didClickItemView(_ sender: Any) {
        selectItem!()
    }
    
}
