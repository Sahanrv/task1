//
//  Game.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/21/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
import UIKit
import SwiftEntryKit

class Game {
    static let playerCount = 4
    static let itemCount = 4
    
    var players = [Player]()
    var items = [Item]()
    var slotItems = [Item]()
    let dilogView = Dialog()
    let tryAgainVindow = SelectItem()
    let gameVc = Game_Vc()
    var playerImage:String!
    
    var winner : Player?
    
    var human : Player? {
        return players.first(where: {$0.isHuman})
    }
    
    var bots : [Player] {
        return players.filter({ !$0.isHuman })
    }
    
    func add(Player player : Player) {
        self.players.append(player)
    }
    
    func initialize() {
        for _ in 0 ..< (Game.playerCount - self.players.count) {
            self.add(Player: Player.random())
        }
        //items = Item.getList()
    }
    
    func selectItem(item : Item, player : Player) {
        player.selectedItem = item
        print("Items : \(items)"  )
        var availableItems = self.items.filter({$0.value != item.value}).shuffled()
        print("availableItems : \(availableItems)"  )
        for bot in self.bots {
            bot.selectedItem = availableItems.popLast()
            print(bot.name,bot.selectedItem?.value)
        }
        print(player.selectedItem?.value)
    }
    
    func spin() {
        self.slotItems = [Item]()
        for _ in self.items {
            self.slotItems.append(self.items.shuffled()[0])
        }
        //self.winner = getWinner()
    }
    
    func getWinner(slotItems : [Item]) -> Player? {
        
        var counts: [Item: Int] = [:]
        for item in slotItems{
            counts[item] = (counts[item] ?? 0) + 1
        }
        
        
        for (key, value) in counts {
            print("\(key.value!) occurs \(value) time(s)")
            
            if(key.value == players[0].selectedItem?.value){
                print(players[0].name)
                checkOccurance(value: value, player: players[0] )
                
            }else if(key.value == players[1].selectedItem?.value){
                print("\(players[1].name)")
                checkOccurance(value: value, player: players[1] )
                
            }else if(key.value == players[2].selectedItem?.value){
                print("\(players[2].name)")
                checkOccurance(value: value, player: players[2] )
                
            }else if(key.value == players[3].selectedItem?.value){
                print("\(players[3].name)")
                checkOccurance(value: value, player: players[3] )
                
            }
            
        }
        
        for x in Game_Vc.game.players{
            
             print("Player Points :",Game_Vc.game.human?.point)
            if Game_Vc.game.human!.point < 2500 {
                Sounds.playSound(type: 6)
                Sounds.tryAgainSound.play()
                self.showRetryDialogView()
            }
            
            if(x.point < 2500){
                x.point = 10000

            }
            
          
        }
        
        for player in self.players {
            if player.isWinner(item: slotItems[0]) {
                print(player.name)
                return player
            }
        }
        return nil
    }
    
    func checkOccurance(value : Int, player : Player){
        if(value == 1){
            print("1 time \(player.name):\(player.isHuman)")
        }
        if(value == 2){
            print("2 time \(player.name):\(player.isHuman)")
            player.point += Int(player.selectedItem!.it)! * 2
            if(player.isHuman){
                print("\(player.name) win")
                 print("Player Image",gameVc.playerImage)
                self.getDialogData(image: self.playerImage, item: player.selectedItem?.value, points: Int(player.selectedItem!.it)! * 2)
                Sounds.playSound(type: 5)
                Sounds.winnerSound.play()
                self.showDialogView()
            }else{
                Sounds.playSound(type: 6)
                Sounds.tryAgainSound.play()
            }
        }
        if(value == 3){
            print("3 time \(player.name):\(player.isHuman)")
            player.point += Int(player.selectedItem!.it)! * 3
            if(player.isHuman){
                print("\(player.name) win")
                print("Player Image",gameVc.playerImage)
                 self.getDialogData(image: self.playerImage, item: player.selectedItem?.value, points: Int(player.selectedItem!.it)! * 3)
                 self.showDialogView()
                Sounds.playSound(type: 5)
                Sounds.winnerSound.play()
            }else{
                Sounds.playSound(type: 6)
                Sounds.tryAgainSound.play()
            }
            
        }
        if(value == 4){
            print("4 time \(player.name):\(player.isHuman)")
            player.point += Int(player.selectedItem!.it)! * 4
            if(player.isHuman){
               // print("\(player.name) win")
                 self.getDialogData(image: self.playerImage, item: player.selectedItem?.value, points: Int(player.selectedItem!.it)! * 4)
                 self.showDialogView()
                Sounds.playSound(type: 5)
                Sounds.winnerSound.play()
            }else{
                Sounds.playSound(type: 6)
                Sounds.tryAgainSound.play()
            }
        }
    }
    
    func getDialogData(image: String!, item:String!, points: Int!){
        dilogView.playerImage.image = UIImage(named: image)
        dilogView.playerLabel.text = "You Earn \(String(points)) Points !"
        dilogView.playerItem.image = UIImage(named: item)
        dilogView.playerItem.restorationIdentifier = item
    }
    
    func showDialogView(){
        var attributes = EKAttributes()
        attributes.displayDuration = EKAttributes.DisplayDuration.init(exactly: 1.5)!
        attributes.position = .center
        attributes.entranceAnimation = .init(translate: .none,
                                             scale: .init(from: 0, to: 1, duration: 0.4),
                                             fade: .init(from: 0, to: 1, duration: 0.2))
        attributes.entryInteraction = .absorbTouches
        SwiftEntryKit.display(entry: dilogView, using: attributes)
    }
    
    func showRetryDialogView(){
        var attributes = EKAttributes()
        attributes.displayDuration = EKAttributes.DisplayDuration.init(exactly: 2.0)!
        attributes.position = .center
        attributes.entranceAnimation = .init(translate: .none,
                                             scale: .init(from: 0, to: 1, duration: 0.4),
                                             fade: .init(from: 0, to: 1, duration: 0.2))
        attributes.entryInteraction = .absorbTouches
        SwiftEntryKit.display(entry: tryAgainVindow, using: attributes)
    }
    
    func reset() {
        self.slotItems = [Item]()
        self.players.forEach({
            $0.reset()
        })
    }
    
    
}



