//
//  Player.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/21/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation
class Player {
    
    var point : Int!
    var name : String!
    var image : String!
    
//    static var botNames = ["Macus","Alexa","Rone","Tron"]
//    static var playerImages = ["ch1","ch2","ch3","ch4"]
    
    static var playerImages: [String]!
     static var botNames: [String]!
    
    
    var selectedItem : Item? {
        didSet {
            guard let item = self.selectedItem else {
                return
            }
            
            self.point -= Int(item.it)!
            
        }
    }
    var isHuman = false
    var isWinner = false
    
    init(withName name : String, point: Int = 10000, isHuman : Bool = false) {
        self.name = name
        self.point = point
        self.isHuman = isHuman
    }
    
    init(withName name : String, image : String, point: Int = 10000, isHuman : Bool = false) {
        self.name = name
        self.image = image
        self.point = point
        self.isHuman = isHuman
    }
    
    func isWinner(item : Item) -> Bool {
        self.isWinner = selectedItem == nil ? false : selectedItem?.it == item.it
        print("isWinner")
        
        //calculatePoints(item: item)
        
        
        return isWinner
    }
    
    func calculatePoints(item : Item){
        var botsValue : Int! = 0
        for x in Game_Vc.game.bots{
            botsValue +=  Int(x.selectedItem!.it)!
        }
        //self.point = point + item.value * 4 + botsValue
    }
    
    func reset() {
        self.isWinner = false
        self.selectedItem = nil
    }
    
    static func random() -> Player {
        botNames = Player.botNames.shuffled()
        playerImages = Player.playerImages.shuffled()
        print("pName : \(botNames)")
        print("pImage : \(playerImages)")
        return Player.init(withName: botNames.popLast()!, image: playerImages.popLast()!)
    }
}
