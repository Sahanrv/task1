//
//  Player.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/15/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import Foundation

class PlayerSet{
    
    var value: String!
    var name: String!
    
    init(value: String!, name: String!){
        self.value = value
        self.name = name
    }
}
