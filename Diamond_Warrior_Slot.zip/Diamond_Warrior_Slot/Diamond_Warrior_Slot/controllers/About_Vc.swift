//
//  About_Vc.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/26/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import UIKit

class About_Vc: UIViewController {
    
    @IBOutlet weak var lblVersion: UILabel!
    @IBOutlet weak var aboutTextArea: UITextView!
    @IBOutlet weak var mainView: UIView!
    var scrollView: UIScrollView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.setVersion()
        // Do any additional setup after loading the view.
    }
    
    
    func setVersion(){
        let version = self.getVersion()
        self.lblVersion.text = "V " + version
    }
    
    func getVersion() -> String{
        
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as! String
    }
    func getBuild() -> String{
        
        return Bundle.main.object(forInfoDictionaryKey: "CFBundleVersion") as! String
    }
    
    @IBAction func didClickBack(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
