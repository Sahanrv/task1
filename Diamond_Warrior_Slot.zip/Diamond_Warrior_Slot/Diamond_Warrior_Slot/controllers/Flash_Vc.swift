//
//  ViewController.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/9/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import UIKit

class Flash_Vc: UIViewController {

    @IBOutlet weak var frameView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.uiConfig()
        self.viewHome()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.viewHome()
    }
    
    func uiConfig(){
        self.frameView.layer.borderColor = UIColor(named: "frame")?.cgColor
        self.frameView.layer.borderWidth = 5
        self.frameView.layer.cornerRadius = 10
    }
    
    func viewHome(){
        DispatchQueue.main.asyncAfter(deadline: .now() , execute: {
            self.performSegue(withIdentifier: "home", sender: nil)
        })
    }


}

