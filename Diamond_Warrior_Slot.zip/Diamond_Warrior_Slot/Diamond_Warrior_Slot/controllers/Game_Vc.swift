//
//  Game_Vc.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/15/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import UIKit
import SwiftEntryKit

class Game_Vc: UIViewController {
    
    
    @IBOutlet weak var slot1: Slot!
    @IBOutlet weak var slot2: Slot!
    @IBOutlet weak var slot3: Slot!
    @IBOutlet weak var slot4: Slot!
    
    @IBOutlet weak var slotView: UIView!
    @IBOutlet weak var diamondImage: UIImageView!
    @IBOutlet weak var diamondView: UIView!
    
    @IBOutlet weak var profileImage: UIView!
    @IBOutlet weak var profileName: UILabel!
    @IBOutlet weak var playerPoint: UILabel!
     @IBOutlet weak var playerDiamond: UIImageView!
    
    @IBOutlet weak var redDiamondBtn: UIButton!
    @IBOutlet weak var orangeDiamondBtn: UIButton!
    @IBOutlet weak var blueDiamondBtn: UIButton!
    @IBOutlet weak var greenDiamondBtn: UIButton!
    
    @IBOutlet weak var itemView1: DiamondView!
    @IBOutlet weak var itemView2: DiamondView!
    @IBOutlet weak var itemView3: DiamondView!
    @IBOutlet weak var itemView4: DiamondView!
    
    @IBOutlet weak var bot1: Warriors!
    @IBOutlet weak var bot2: Warriors!
    @IBOutlet weak var bot3: Warriors!
    
    @IBOutlet weak var spinButton: UIButton!
    
    @IBOutlet weak var dialogViewFrame: UIView!
    var selectedItemView: UIView!
    static let game = Game()
    
    let defaults = UserDefaults.standard
    var playerData: PlayerSet!
    static var human: Player!
    var imgArray = [Item]()
    let dilogView = Dialog()
    let selctItemView = SelectItems()
    var PlayerImageArray =  ["ch1","ch2","ch3","ch4"]
    var PlayerNameArray = ["Macus","Alexa","Rone","Tron"]
    
    var playerName: String!{
        didSet{
            self.setBotArray()
            Game_Vc.human = Player.init(withName: playerName , isHuman: true)
        }
    }
    
    var playerImage: String!{
        didSet{
            setPlayer()
        }
    }
    var diamond: String!
    
    var result1 = Item()
    var result2 = Item()
    var result3 = Item()
    var result4 = Item()

    var res1: String!
    var res2: String!
    var res3: String!
    var res4: String!{
        didSet{
            self.findWinner()
        }
    }
    
    var timeStop: Int!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.uiConfig()
       self.playerConfiger()
        self.playerDataConfig()
        setItemPanel()
        
        Player.botNames = PlayerNameArray
        Player.playerImages = PlayerImageArray
        self.setBotArray()
        Game_Vc.game.players = [Player]();
        Game_Vc.game.playerImage = self.playerImage
        Game_Vc.game.add(Player: Game_Vc.human)
        Game_Vc.game.initialize()
        self.playSound()
        self.setBots()
        
    }
    
    func playSound(){
        Sounds.audioPlayer.volume = 0.2
    }
    
    func setBotArray(){
        
        print ("Player Temp Name :",playerImage)
        if playerImage == "ch1" {
            var playersTemp = self.PlayerImageArray.filter({$0 != self.playerImage})
            Player.playerImages = playersTemp
            print("Players Temp : " ,Player.playerImages)
        }else if playerImage == "ch2" {
            var playersTemp = self.PlayerImageArray.filter({$0 != self.playerImage})
            Player.playerImages = playersTemp
        }else if playerImage == "ch3" {
            var playersTemp = self.PlayerImageArray.filter({$0 != self.playerImage})
            Player.playerImages = playersTemp
            print("Players Temp : " ,Player.playerImages)
        }else if playerImage == "ch4" {
            var playersTemp = self.PlayerImageArray.filter({$0 != self.playerImage})
            Player.playerImages = playersTemp
            print("Players Temp : " ,Player.playerImages)
        }
        
        if playerName == "Macus" {
            var playersTemp = self.PlayerNameArray.filter({$0 != self.playerName})
            Player.botNames = playersTemp
            print("Players Temp : " ,Player.playerImages)
        }else if playerImage == "Alexa" {
            var playersTemp = self.PlayerNameArray.filter({$0 != self.playerName})
            Player.botNames = playersTemp
        }else if playerImage == "Rone" {
            var playersTemp = self.PlayerNameArray.filter({$0 != self.playerName})
            Player.botNames = playersTemp
            print("Players Temp : " ,Player.botNames)
        }else if playerImage == "Tron" {
            var playersTemp = self.PlayerNameArray.filter({$0 != self.playerName})
            Player.botNames = playersTemp
            print("Players Temp : " ,Player.botNames)
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {

        imgArray = [
            Item(value: "d1", it: "1000"),
            Item(value: "d2", it: "1500"),
            Item(value: "d3", it: "2000"),
            Item(value: "d4", it: "2500")
        ]
        
        Game_Vc.game.items = imgArray
        
        slot1.viewType = .image
        slot2.viewType = .image
        slot2.isReverse = true
        slot3.viewType = .image
        slot4.viewType = .image
        slot4.isReverse = true
        
         DispatchQueue.main.async {
        
            self.slot1.initializeViews(dataSource: self.imgArray)
            self.slot2.initializeViews(dataSource: self.imgArray)
            self.slot3.initializeViews(dataSource: self.imgArray)
            self.slot4.initializeViews(dataSource: self.imgArray)
        //slot1.initializeViews()
        
        self.itemView1.selectItem = {
            if Game_Vc.human.selectedItem == nil {
                self.playItemPickSound()
                Game_Vc.game.selectItem(item: self.imgArray[0], player: Game_Vc.human)
                self.playerDiamond.image = UIImage(named: (Game_Vc.game.human?.selectedItem?.value!)!)
                self.playerPoint.text = String(Game_Vc.game.human!.point!)
                self.playerPoint.textColor = UIColor(named: self.pointColor(item: (Game_Vc.game.human?.selectedItem?.value!)!))
                self.setSelectedItemStyle(itemView: self.itemView1, color: "d1c")
                self.setBotItems()
                
            }
        }
        self.itemView2.selectItem = {
            if Game_Vc.human.selectedItem == nil {
                self.playItemPickSound()
                Game_Vc.game.selectItem(item: self.imgArray[1], player: Game_Vc.human)
                print("Second Time Pic  :",Game_Vc.game.human?.selectedItem?.value!)
                self.playerDiamond.image = UIImage(named: (Game_Vc.game.human?.selectedItem?.value!)!)
                self.playerPoint.text = String(Game_Vc.game.human!.point!)
                self.playerPoint.textColor = UIColor(named: self.pointColor(item: (Game_Vc.game.human?.selectedItem?.value!)!))
                self.setSelectedItemStyle(itemView: self.itemView2, color: "d2c")
                self.setBotItems()
                
            }
        }
        self.itemView3.selectItem = {
            self.playItemPickSound()
            if Game_Vc.human.selectedItem == nil {
                Game_Vc.game.selectItem(item: self.imgArray[2], player: Game_Vc.human)
                self.playerDiamond.image = UIImage(named: (Game_Vc.game.human?.selectedItem?.value!)!)
                self.playerPoint.text = String(Game_Vc.game.human!.point!)
                self.playerPoint.textColor = UIColor(named: self.pointColor(item: (Game_Vc.game.human?.selectedItem?.value!)!))
                self.setSelectedItemStyle(itemView: self.itemView3, color: "d3c")
                self.setBotItems()
                
            }
        }
        self.itemView4.selectItem = {
            self.playItemPickSound()
            if Game_Vc.human.selectedItem == nil {
                Game_Vc.game.selectItem(item: self.imgArray[3], player: Game_Vc.human)
                self.playerDiamond.image = UIImage(named: (Game_Vc.game.human?.selectedItem?.value!)!)
                self.playerPoint.text = String(Game_Vc.game.human!.point!)
                self.playerPoint.textColor = UIColor(named: self.pointColor(item: (Game_Vc.game.human?.selectedItem?.value!)!))
                self.setSelectedItemStyle(itemView: self.itemView4, color: "d4c")
                self.setBotItems()
                
            }
        }
            
        }
    }
    
    func setSelectedItemStyle(itemView : UIView, color: String!){
        self.selectedItemView = itemView
        itemView.layer.borderWidth = 2
        itemView.layer.borderColor = UIColor(named: color)?.cgColor
        itemView.layer.cornerRadius = 5
        
    }
    
    func removeSelectedItemStyle(){
        self.selectedItemView.layer.borderWidth = 0
    }
    
    func playerDataConfig(){
        print("Final Value Of Human", Game_Vc.human!.point)
        self.playerPoint.text = String(Game_Vc.human.point)
    }
    
    func setBots(){
        
        bot1.botImage.image = UIImage(named: Game_Vc.game.bots[0].image)
        bot1.botName.text = Game_Vc.game.bots[0].name
        bot1.botPoints.text = String(Game_Vc.game.bots[0].point)
        
        bot2.botImage.image = UIImage(named: Game_Vc.game.bots[1].image)
        bot2.botName.text = Game_Vc.game.bots[1].name
        bot2.botPoints.text = String(Game_Vc.game.bots[1].point)
        
        bot3.botImage.image = UIImage(named: Game_Vc.game.bots[2].image)
        bot3.botName.text = Game_Vc.game.bots[2].name
        bot3.botPoints.text = String(Game_Vc.game.bots[2].point)
        
    }
    
    func setBotItems(){
        bot1.botItem.image = UIImage(named: Game_Vc.game.bots[0].selectedItem!.value)
        bot1.botPoints.text = String(Game_Vc.game.bots[0].point)
        bot1.botPoints.textColor = UIColor(named: pointColor(item: Game_Vc.game.bots[0].selectedItem!.value))
        
        bot2.botItem.image = UIImage(named: Game_Vc.game.bots[1].selectedItem!.value)
        bot2.botPoints.text = String(Game_Vc.game.bots[1].point)
        bot2.botPoints.textColor = UIColor(named: pointColor(item: Game_Vc.game.bots[1].selectedItem!.value))
        
        bot3.botItem.image = UIImage(named: Game_Vc.game.bots[2].selectedItem!.value)
        bot3.botPoints.text = String(Game_Vc.game.bots[2].point)
        bot3.botPoints.textColor = UIColor(named: pointColor(item: Game_Vc.game.bots[2].selectedItem!.value))
        
    }
    
    func pointColor(item: String)-> String {
        var color = ""
        if item == "d1" {
            color = "d1c"
        }else if item == "d2" {
            color = "d2c"
        }else if item == "d3" {
            color = "d3c"
        }else if item == "d4" {
            color = "d4c"
        }
        return color
    }
    
    func setItemPanel(){
        
        itemView1.itemImage.image = UIImage.init(named: "d1")
        itemView1.itemPoints.text = "1000"
        itemView2.itemImage.image = UIImage.init(named: "d2")
        itemView2.itemPoints.text = "1500"
        itemView3.itemImage.image = UIImage.init(named: "d3")
        itemView3.itemPoints.text = "2000"
        itemView4.itemImage.image = UIImage.init(named: "d4")
        itemView4.itemPoints.text = "2500"
        
    }
    
    func uiConfig(){
        self.slotView.layer.cornerRadius = 10
        self.diamondView.layer.cornerRadius = 10
    }
    
    func setPlayer(){
        self.diamondImage.image = UIImage(named: self.playerImage)
        self.profileName.text = self.playerName
    }
    
    
    func playerConfiger(){
    
        if playerData?.value != nil {
            self.playerName = self.playerData.name
            self.playerImage = self.playerData.value
            print(self.playerName!)
        }else{
            self.playerName = "Macus"
            self.playerImage = "ch1"
        }
    }

    func findWinner(){
            
            let slotArray : [Item] = [result1,result2,result3,result4]
        print("Human 1st :",Game_Vc.human.point)
            let _ = Game_Vc.game.getWinner(slotItems : slotArray)
            print("Human 2nd :",Game_Vc.human.point)
            Game_Vc.game.human?.selectedItem = nil
            setBotItems()
            self.playerPoint.text = String(Game_Vc.human.point)
            self.removeSelectedItemStyle()
    }
    
    func removeItem(){
        self.playerDiamond.image = UIImage(named: "")
    }
    
    func playSlotMachineSound(){
        Sounds.playSound(type: 4)
        Sounds.slotMachineSound.play()
    }
    
    func playItemPickSound(){
        Sounds.playSound(type: 3)
        Sounds.itemPickSound.play()
    }
    
    func showSelectItemDialogView(){
        var attributes = EKAttributes()
        attributes.displayDuration = EKAttributes.DisplayDuration.init(exactly: 1.0)!
        attributes.position = .center
        attributes.entranceAnimation = .init(translate: .none,
                                             scale: .init(from: 0, to: 1, duration: 0.4),
                                             fade: .init(from: 0, to: 1, duration: 0.2))
        attributes.entryInteraction = .absorbTouches
        SwiftEntryKit.display(entry: selctItemView, using: attributes)
    }
    
    @IBAction func didClickSpinButton(_ sender: Any) {
        //showDialogView()
        if Game_Vc.game.human?.selectedItem != nil {
        
           self.timeStop  = Int.random(in: 4...10 )
            
            self.spinButton.isEnabled = false
           
            _ = Timer.scheduledTimer(timeInterval: Double(timeStop - 2) , target: self, selector: #selector(fire), userInfo: nil, repeats: false)
        
          self.result1 = imgArray.shuffled()[0]
            
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
                self.playSlotMachineSound()
                self.slot1.animate(finalValue: self.result1, times: self.timeStop, speed: 0.9, completion: {
                    print("slot 1 ", self.slot1.finalValue!.value!)
                    self.res1 = self.slot1.finalValue!.value
                    
                    
                })
                self.result2 = self.imgArray.shuffled()[0]
                
                
                self.slot2.animate(finalValue: self.result2, times: self.timeStop, speed: 0.7, completion: {
                    print("slot 2 ", self.slot2.finalValue!.value!)
                    self.res2 = self.slot2.finalValue!.value
                    
                    
                })
                self.result3 = self.imgArray.shuffled()[0]
                
                
                self.slot3.animate(finalValue:  self.result3, times: self.timeStop, speed: 0.8, completion: {
                    print("slot 3 ", self.slot3.finalValue!.value!)
                    self.res3 = self.slot3.finalValue!.value
                    
                    
                })
                
                self.result4 = self.imgArray.shuffled()[0]
                
                
                self.slot4.animate(finalValue:   self.result4 , times: self.timeStop, speed: 0.9, completion: {
                    print("slot 4 ", self.slot4.finalValue!.value!)
                    self.res4 = self.slot3.finalValue!.value
                    Sounds.slotMachineSound.stop()
                    
                })
                
                print("Button Click Spin")
           
            }
            
        }else{
            print("Select An Item")
            self.showSelectItemDialogView()
            
        }

    }
    
    @objc func fire(){
        self.spinButton.isEnabled = true
    }
    
    @IBAction func didClickBackButton(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
