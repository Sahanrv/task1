//
//  Player_Vc.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/15/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import UIKit

class Player_Vc: UIViewController {

    @IBOutlet weak var framePlayer: UIView!
    @IBOutlet weak var player: UIImageView!
    @IBOutlet weak var pl1: UIImageView!
    @IBOutlet weak var pl2: UIImageView!
    @IBOutlet weak var pl3: UIImageView!
    @IBOutlet weak var pl4: UIImageView!
    
    @IBOutlet weak var playerLab1: UILabel!
    @IBOutlet weak var playerLab2: UILabel!
    @IBOutlet weak var playerLab3: UILabel!
    @IBOutlet weak var playerLab4: UILabel!
    
    @IBOutlet weak var playerName: UITextField!
    
    let defaults = UserDefaults.standard
    
    var imageName: String!
    
    var playerData: PlayerSet!
    
    //static let game = Game()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.uiConfig()
        self.addPlayerGuestures()
       

        // Do any additional setup after loading the view.
    }
    
    func addPlayerGuestures(){
        
        let playerOne = UITapGestureRecognizer(target: self, action: #selector(playerOneAdd))
        let playerTwo = UITapGestureRecognizer(target: self, action: #selector(playerTwoAdd))
        let playerThree = UITapGestureRecognizer(target: self, action: #selector(playerThreeAdd))
        let playerFour = UITapGestureRecognizer(target: self, action: #selector(playerFourAdd))
        
        pl1.addGestureRecognizer(playerOne)
        pl1.isUserInteractionEnabled = true
        
        pl2.addGestureRecognizer(playerTwo)
        pl2.isUserInteractionEnabled = true
        
        pl3.addGestureRecognizer(playerThree)
        pl3.isUserInteractionEnabled = true
        
        pl4.addGestureRecognizer(playerFour)
        pl4.isUserInteractionEnabled = true
        
    }
    
    
    @objc func playerOneAdd(){
        self.player.image = UIImage(named: "ch1")
        self.imageName = "ch1"
        self.playerName.text = playerLab1.text
    }
    @objc func playerTwoAdd(){
        self.player.image = UIImage(named: "ch2")
        self.imageName = "ch2"
        self.playerName.text = playerLab2.text
    }
    @objc func playerThreeAdd(){
        self.player.image = UIImage(named: "ch3")
        self.imageName = "ch3"
        self.playerName.text = playerLab4.text
    }
    @objc func playerFourAdd(){
        self.player.image = UIImage(named: "ch4")
        self.imageName = "ch4"
        self.playerName.text = playerLab3.text
    }
    
    func uiConfig(){
        self.framePlayer.layer.borderColor = UIColor(named: "frame")?.cgColor
        self.framePlayer.layer.borderWidth = 3
        self.framePlayer.layer.cornerRadius = 10
        
        self.playerName.text = playerLab1.text
        
        self.imageName = "ch1"
        
        
        
    }
    
    @IBAction func didClickSave(_ sender: Any) {
        
        //let playerProf  = self.player.description
        let name = self.playerName.text!
        
        if self.imageName == "ch1" {
            self.playerLab1.text = name
        }else if self.imageName == "ch2" {
            self.playerLab2.text = name
        }else if self.imageName == "ch4" {
            self.playerLab3.text = name
        }else if self.imageName == "ch3" {
            self.playerLab4.text = name
        }
        
       let player = PlayerSet(value: self.imageName, name: name)
    
        self.playerData = player
        
        //print(playerData[0].name)
        
        performSegue(withIdentifier: "game", sender: self.playerData)
        //self.dismiss(animated: true, completion: nil)
       // defaults.set(self.playerData, forKey: "playerKey")
    
        //defaults.synchronize()
    }
    
    @IBAction func didClickBack(_ sender: Any) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "game"{
            let vc = segue.destination as! Game_Vc
            vc.playerData = self.playerData
            
            
            //Data has to be a variable name in your RandomViewController
        }
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
