//
//  Home_Vc.swift
//  Diamond_Warrior_Slot
//
//  Created by Treinetic Macbook 001 on 8/12/19.
//  Copyright © 2019 Treinetic Macbook 001. All rights reserved.
//

import UIKit

class Home_Vc: UIViewController {


//    @IBOutlet weak var frameView: UIView!
    @IBOutlet weak var startGameButton: UIButton!
    @IBOutlet weak var playerButton: UIButton!
    @IBOutlet weak var howToPlayButton: UIButton!
    @IBOutlet weak var titleImage: UIImageView!
    @IBOutlet weak var exitButton: UIButton!
    @IBOutlet weak var aboutButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.uiConfig()
        self.playSound()
        print(UIDevice.current.model)

        // Do any additional setup after loading the view.
    }
    
    func playSound(){
        Sounds.playSound(type: 1)
        Sounds.audioPlayer.play()
    }
    
    func uiConfig(){
        if UIDevice.current.model == "iPhone" {
            
            self.startGameButton.layer.cornerRadius = self.startGameButton.bounds.height / 2
            self.playerButton.layer.cornerRadius = self.playerButton.bounds.height / 2
            self.howToPlayButton.layer.cornerRadius = self.howToPlayButton.bounds.height / 2
            self.exitButton.layer.cornerRadius = self.exitButton.bounds.height / 2
            self.aboutButton.layer.cornerRadius = self.aboutButton.bounds.height / 2
        }else{
            
//            self.titleImage.getLayoutParams(). = 480.0
            
            self.startGameButton.layer.cornerRadius = 30
            self.playerButton.layer.cornerRadius = 30
            self.howToPlayButton.layer.cornerRadius = 30
            self.exitButton.layer.cornerRadius = 30
            self.aboutButton.layer.cornerRadius = 30
            
            self.titleImage.contentMode = .scaleAspectFit
            
        }
        
        self.startGameButton.clipsToBounds = true
        self.playerButton.clipsToBounds = true
        self.howToPlayButton.clipsToBounds = true
        
    }
    @IBAction func didClickStartGame(_ sender: Any) {
        print("Clicked")
    }
    
    @IBAction func didClickExit(_ sender: Any) {
        
        exit(0)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
